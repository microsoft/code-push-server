import http = require("http");
import https = require("https");
import Q = require("q");
import Storage = require("../script/storage/storage.d");
import stream = require("stream");

import Promise = Q.Promise;

class Utils {
    static makeLocalAccount(): Storage.LocalAccount {
        var localAccount = <Storage.LocalAccount>{
            name: "test account",
            description: "test description",
            email: "test@email.com",
            clientSecret: "123",
            websiteSecret: "abc",
            username: "testuser",
            saltedPassword: "$password$salt$"
        };

        return localAccount;
    }

    static makeProviderAccount(): Storage.ProviderAccount {
        var providerAccount = <Storage.ProviderAccount>{
            name: "test account",
            description: "test description",
            email: "test@email.com",
            clientSecret: "123",
            websiteSecret: "abc",
            provider: "test provider",
            providerUniqueId: "123abc"
        };

        return providerAccount;
    }

    static makeApp(): Storage.App {
        var app = <Storage.App>{
            name: "test app",
            description: "test description"
        };

        return app;
    }

    static makeDeployment(): Storage.Deployment {
        var deployment = <Storage.Deployment>{
            name: "test deployment",
            description: "test description"
        };

        return deployment;
    }

    static makePackage(): Storage.Package {
        var storagePackage = <Storage.Package>{
            blobId: "test blob id",
            description: "test blob id",
            isMandatory: false,
            nativeVersion: "test blob id",
            scriptVersion: "test blob id"
        }

        return storagePackage;
    }

    static makeAccess(): Storage.Access {
        var access = <Storage.Access>{
            description: "test access",
            isPrimary: false
        };

        return access;
    }

    static makeStreamFromString(stringValue: string): stream.Readable {
        var blobStream = new stream.Readable();
        blobStream.push(stringValue);
        blobStream.push(null);
        return blobStream;
    }

    static makeStringFromStream(stream: stream.Readable): Promise<string> {
        var stringValue = "";
        return Q.Promise((resolve: (stringValue: string) => void) => {
            stream
                .on("data", (data: string) => {
                    stringValue += data;
                })
                .on("end", () => {
                    resolve(stringValue);
                });
        });
    }

    static retrieveStringContentsFromUrl(url: string): Promise<string> {
        var protocol: typeof http|typeof https = null;
        if (url.indexOf("https://") === 0) {
            protocol = https;
        } else {
            protocol = http;
        }

        return Q.Promise((resolve: (stringValue: string) => void) => {
            protocol.get(url, (response: http.IncomingMessage) => {
                if (response.statusCode !== 200) {
                    return null;
                }

                Utils.makeStringFromStream(response)
                    .then((contents: string) => {
                        resolve(contents);
                    });
            }).on("error", (error: any) => {
                resolve(null);
            });
        });
    }
}

export = Utils;